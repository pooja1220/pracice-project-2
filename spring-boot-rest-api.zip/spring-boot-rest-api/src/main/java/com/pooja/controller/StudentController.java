package com.pooja.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.pooja.bean.Student;

@RestController
@RequestMapping("students")
public class StudentController {

	// spring boot rest api that returns java bean as json
	// http://localhost:8080/student
	@GetMapping("student")
    public Student getStudent() {
	Student student=new Student(
     id : 1,
	"firstName" : "Pooja",
	lastName : "Chouhan"
			);
	return student;
    }

	// spring boot rest api that returns java bean as json , using Response Entity
	// http://localhost:8080/student
	@GetMapping("student")
	    public ResponseEntity<Student> getStudent() {
		Student student=new Student(
	     id : 1,
		firstName : "Pooja",
		lastName : "Chouhan"
		);
		return new ResponseEntity<>(student,HttpStatus.OK);
		//or
		return ResponseEntity.ok(student);
	    
	   // to pass HttpHeaders in HttpResponse using ResponseEntity class
	return ResponseEntity.ok()
			.header(headerName:"custom-header", headerValue:"pooja")
			.body(student);
	}

	// spring boot rest api that returns list as json
	// http://localhost:8080/students
	// @GetMapping("students")
	@GetMapping
	public List<Student> getStudents(){
		List<Student> students =new ArrayList<>();
		students.add(new Student(id:2,firstName:"Hitesh",lastName:"Chouhan"));
		students.add(new Student(id:3,firstName:"Lalith",lastName:"Chouhan"));
		students.add(new Student(id:4,firstName:"Papulal",lastName:"Chouhan"));
		return students;
		}

	// spring boot rest api that returns list as json using ResponseEntity
	// http://localhost:8080/students
	// @GetMapping("students")
	@GetMapping
		public ResponseEntity<List<Student>> getStudents(){
			List<Student> students =new ArrayList<>();
			students.add(new Student(id:2,firstName:"Hitesh",lastName:"Chouhan"));
			students.add(new Student(id:3,firstName:"Lalith",lastName:"Chouhan"));
			students.add(new Student(id:4,firstName:"Papulal",lastName:"Chouhan"));
			return ResponseEntity.ok(students);
			}

	// spring boot rest api with PathVariable
	// {id} URI template variable
	// http://localhost:8080/students/1
	// @GetMapping("students/{id}")
	@GetMapping("{id}")
    public Student studentPathVariable(@PathVariable("id") int studentId) {
        return new Student(studentId,firstName:"shyam",lastName:"padiyar");
         }

	// spring boot rest api with PathVariable using ResponseEntity
	// {id} URI template variable
	// http://localhost:8080/students/1
	// @GetMapping("students/{id}")
	@GetMapping("{id}")
	    public ResponseEntity<Student> studentPathVariable(@PathVariable("id") int studentId) {
	        Student student= new Student(studentId,firstName:"shyam",lastName:"padiyar");
	        return ResponseEntity.ok(student);
	         }

	// to pass multiple path variable
	// http://localhost:8080/students/1/shyam/padiyar
	// @GetMapping("students/{id}/{first-name}/{last-name}")
	@GetMapping("{id}/{first-name}/{last-name}")
	public Student studentPathVariable(@PathVariable("id") int studentId, @PathVariable("first-name") String firstName,
			@PathVariable("last-name") String lastName) {
		return new Student(studentId, firstName, lastName);
	}

	// Spring boot rest api with Requestparam
	// http://localhost:8080/students/query?id=1
	// @GetMapping("students/query")
	@GetMapping("query")
	public Student studentRequestVariabe(@RequestParam int id ) {
		return new Student(id,firstName:"shyam",lastName:"padiyar");
	}

	// Spring boot rest api with Requestparam with ResponseEntity
	// http://localhost:8080/students/query?id=1
	// @GetMapping("students/query")
	@GetMapping("query")
		public ResponseEntity<Student> studentRequestVariabe(@RequestParam int id ) {
			Student student = new Student(id,firstName:"shyam",lastName:"padiyar");
			return ResponseEntity.ok(student)
		}

	// handling multiple query parameters
	// http://localhost:8080/students/query?id=1&firstName=shyam&lastName=padiyar
	// @GetMapping("students/query")
	@GetMapping("query")
	public Student studentRequestVariabe(@RequestParam int id, @RequestParam String firstName,
			@RequestParam String lastName) {
		return new Student(id, firstName, lastName);
	}

	// spring boot rest api that handles HTTP Post request
	// @PostMapping and @RequestBody
	// http://localhost:8080/students/create
	// @PostMapping("students/create")
	@PostMapping("create")
	@ResponseStatus(HttpStatus.CREATED)
	public Student createStudent(@RequestBody Student student) {
		System.out.println(student.getId());
		System.out.println(student.getFirstName());
		System.out.println(student.getLastName());
		return student;
	}

	// spring boot rest api that handles HTTP Post request
	// @PostMapping and @RequestBody
	// http://localhost:8080/students/create
	// @PostMapping("students/create")
	@PostMapping("create")
//	@ResponseStatus(HttpStatus.CREATED)
	public ResponseEntity<Student> createStudent(@RequestBody Student student) {
		System.out.println(student.getId());
		System.out.println(student.getFirstName());
		System.out.println(student.getLastName());
		return new ResponseEntity<>(student, HttpStatus.CREATED);
	}

	// spring boot rest api that handles HTTP PUT request
	// @PutMapping and @RequestBody
	// @PutMapping("students/{id}/update")
	@PutMapping("{id}/update")
	public Student updateStudent(@RequestBody Student student, @PathVariable("id") int studentId) {
		System.out.println(student.getFirstName());
		System.out.println(student.getLastName());
		return student;
	}

	// spring boot rest api that handles HTTP PUT request with ResponseEntity
	// @PutMapping and @RequestBody
	// @PutMapping("students/{id}/update")
	@PutMapping("{id}/update")
	public ResponseEntity<Student> updateStudent(@RequestBody Student student, @PathVariable("id") int studentId) {
		System.out.println(student.getFirstName());
		System.out.println(student.getLastName());
		return ResponseEntity.ok(student);

	}

	// spring boot rest api that handles HTTP Delete request
	// @DeleteMapping
	// @DeleteMapping("students/{id}/delete")
	@DeleteMapping("{id}/delete")
	public ResponseEntity<String> deleteStudent(@PathVariable("id") int studentId) {
		System.out.println(studentId);
		return ResponseEntity.ok("Student deleted successfully");
	}
}
